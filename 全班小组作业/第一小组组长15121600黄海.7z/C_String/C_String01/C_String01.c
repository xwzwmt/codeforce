// C_String01.c		���ļ�����Ҫ����4�������Ķ��壨������ʵ�֣�
#include <stdlib.h>
#include <string.h>
#include<malloc.h>
#include"c_string01.h"
// ���� SWAP1��SWAP2��SWAP3��STRCAT�Ķ���
void swap1(char str1[],char str2[])
{
	char str[10];
	int i;
	for(i=0;str1[i]!='\0';i++)
	{
		str[i]=str1[i];
	}
	str[i]='\0';
	for(i=0;str2[i]!='\0';i++)
	{
		str1[i]=str2[i];
	}
	str1[i]='\0';
	for(i=0;str[i]!='\0';i++)
	{
		str2[i]=str[i];
	}
	str2[i]='\0';
}

void swap2(char *p1,char *p2)
{
	char *p;
	int l;
	l=strlen(p1);
	if(strlen(p2)>strlen(p1))
		l=strlen(p2);
	p=(char*)calloc(l,sizeof(char));
	strcpy(p,p1);
	strcpy(p1,p2);
	strcpy(p2,p);
	free(p);
}

void swap3(char **str1,char **str2)
{
	char *p;
	p=*str1;
	*str1=*str2;
	*str2=p;	
}

void STRCAT(char *str1,char *str2)
{
	int i,len1=strlen(str1),len2=strlen(str2);
	char *p = (char *)malloc(sizeof(char)*(len1+len2+3));
	for(i=0;i<len1;i++)
	{
		*(p+i)=*(str1+i);
	}
	*(p+i)=' ';
	*(p+i+1)='&';
	*(p+i+2)=' ';
	for(i=0;i<len2;i++)
	{
		*(p+len1+3+i)=*(str2+i);
	}
	*(p+len1+len2+3)='\0';
	for(i=0;*(p+i)!='\0';i++)
	{
		*(str1+i)=*(p+i);
	}
	*(str1+i)='\0';
	free(p);
}

