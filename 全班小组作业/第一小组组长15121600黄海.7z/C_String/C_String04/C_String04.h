int sort11(char str[12][8]);
int sort12(char *str[12]);
int sort21(char str[12][8]);
int sort22(char *str[12]);
