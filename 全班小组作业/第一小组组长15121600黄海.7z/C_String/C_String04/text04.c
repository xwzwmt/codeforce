#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <conio.h>
#include "c_string04.h"

void test11()
{
	int i;
	char str[12][8]={"enter", "number", "size", "begin", "of", "cat", "case", "program", "centain", "a", "cake", "side"}; 
	printf("in test11()\n");
	printf("Before: ");
	for(i=0;i<12;i++)
		printf("%s ",str[i]);
	printf("\n");
	sort11(str);
	printf("After: ");
	for(i=0;i<12;i++)
		printf("%s ",str[i]);
	printf("\n");
	printf("return from test11()\n");
}

void test12()
{
	int i;
	char *str[12]={"enter","number","size","begin","of","cat","case","program","centain","a","cake","side"};
	printf("in test12()\n");
	printf("Before: ");
	for(i=0;i<12;i++)
		printf("%s ",str[i]);
	printf("\n");
	sort12(str);
	printf("After: ");
	for(i=0;i<12;i++)
		printf("%s ",str[i]);
	printf("\n");
	printf("return from test12()\n");
}

void test21()
{
	int i;
	char str[12][8]={"enter", "number", "size", "begin", "of", "cat", "case", "program", "centain", "a", "cake", "side"}; 
	printf("in test21()\n");
	printf("Before: ");
	for(i=0;i<12;i++)
		printf("%s ",str[i]);
	printf("\n");
	sort21(str);
	printf("After: ");
	for(i=0;i<12;i++)
		printf("%s ",str[i]);
	printf("\n");
	printf("return from test21()\n");
}

void test22()
{
	int i;
	char *str[12]={"enter","number","size","begin","of","cat","case","program","centain","a","cake","side"}; 
	printf("in test22()\n");
	printf("Before: ");
	for(i=0;i<12;i++)
		printf("%s ",str[i]);
	printf("\n");
	sort22(str);
	printf("After: ");
	for(i=0;i<12;i++)
		printf("%s ",str[i]);
	printf("\n");
	printf("return from test22()\n");
}

int main()
{
	int choice = 1;
	void (*f[])() = {test11, test12, test21, test22};
	
	while(1)
	{
		printf("\nC-String test. Your choice(1--4, 0-quit): ");
		choice = getche() - '0';
		printf("\n");

		if(choice<=0)
			break;
		else if(choice>4)
			continue;
		else
			f[choice-1]();
	}
	return 0;
}
