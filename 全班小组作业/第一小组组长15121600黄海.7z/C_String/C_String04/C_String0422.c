#include<string.h>
#include"c_string04.h"
int sort22(char *str[12])
{
	int i,j;
	char *p; 
	for(i=0;i<12;i++)
	{
		for(j=i+1;j<12;j++)
		{
			if(strlen(str[i])>strlen(str[j]))
			{
				p=str[i];
				str[i]=str[j];
				str[j]=p;
			}
			if(strlen(str[i])==strlen(str[j]))
			{
				if(strcmp(str[i],str[j])>0)
				{
					p=str[i];
					str[i]=str[j];
					str[j]=p;
				}
			}
		}
	}
	return 0;
}
