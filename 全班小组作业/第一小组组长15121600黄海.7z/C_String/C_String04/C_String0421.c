#include<string.h>
#include"c_string04.h"
int sort21(char str[12][8])
{
	int i,j;
	char s[8];
	for(i=0;i<12;i++)
	{
		for(j=i+1;j<12;j++)
		{
			if(strlen(str[i])>strlen(str[j]))
			{
				strcpy(s,str[i]);
					strcpy(str[i],str[j]);
					strcpy(str[j],s);
			}
			if(strlen(str[i])==strlen(str[j]))
			{
				if(strcmp(str[i],str[j])>0)
				{
					strcpy(s,str[i]);
					strcpy(str[i],str[j]);
					strcpy(str[j],s);
				}
		    }
		}
	}
	return 0;		
}
