#include<stdio.h>
#include<stdlib.h>
#include"c_string.h"
int main()
{
	char s[100];
	
	return 0;
}