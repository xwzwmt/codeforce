int *AtoI(char c);
char *StrUpr(char *str);
char *StrLwr(char *str);
int StrLen(char *scourse);
char *StrCpy(char *str,const char *scourse);   
char *StrnCpy(char *dest, const char *src, int n);
int StrCmp(const char *str1,const char *str2);
char *StrCat(char *dest,char *src);
